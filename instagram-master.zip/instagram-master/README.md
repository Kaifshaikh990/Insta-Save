# Instagram Downloader

Its Source Of Instagram Downloader Bot .This Bot Helps In Downloading __Instagram Photos__ and __Videos__ Using IG Public API. For Now It Works Only For **Public Accounts**. No Login or Money Required Just send The Instagram Post Link to Bot, It Will Send Video/Photo In Return.

<p align="center">
  <img src="https://sm.ign.com/ign_in/screenshot/default/ig-glyph001-74am_dp6a.jpg" alt="Instagram"/>
</p>

## Requirements

> python-telegram-bot\
> requests

---

## Setup

To Make Your Own Bot Using This Source. Follow Below Steps

> Go To [@BotFather](https://t.me/botfather) and Collect Your Bot Token


### Setup using Heroku

> Can Cause Error, Because Instagram Blocks Heroku IP

* Fork This Repo
* Open main.py and Paste Your Bot Token in __TOKEN__ Variable
* Make Account On Heroku.com
* Click New App
* Give Name To Your App of Your Choice
* Connect Heroku To Your Github By Clicking Deploy and then Deployment method in Your Heroku app
* Search Your Forked Repo Name
* Click Deploy, Wait Till Deployment
* Go To Dynos, Turn It On and Check Your Bot

### Locally Running On Server (I Prefer This) 

* Fork This Repo
* Open main.py and Paste Your Bot Token in __TOKEN__ Variable
* Download Forked Repo
* On Terminal run Command
```bash
pip install -r requirements.txt

python main.py
```
---

## Credits

> Its Written by [@TheDarkW3b](https://t.me/TheDarkW3b)
* Support Group :- https://t.me/Technology_Arena
* Channel :- https://t.me/Dark_Hacker_X
